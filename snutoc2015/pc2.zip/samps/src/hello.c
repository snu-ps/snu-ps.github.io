/*
 * File:    hello.c 
 * Purpose: prints: Hello World.
 * Author:  pc2@ecs.csus.edu or http://www.ecs.csus.edu/pc2
 *
 * $Id: hello.c 1962 2009-11-25 03:42:12Z boudreat $
 *
 */

#include <stdio.h>
#include <stdlib.h>

main()
{
        printf("Hello World.\n");
        
        exit(0);
}

/* eof */
